//function for the body
function bindbodycontent() {
  //Id for the whole sceem

  var body = document.getElementById('main-body');
  var div_main = document.createElement('div');
  div_main.className = 'fullscreen';

  //For block-1(Signup)
  var div_block1 = document.createElement('div');
  div_block1.className = 'block1-signup col-5 col-m-5';

  //For block-1(Signup) header
  var div_block1_signup = document.createElement('div');
  div_block1_signup.className = "signup-head";
  var div_block1_signup_h1 = document.createElement('h1');
  div_block1_signup_h1.innerHTML = "Signup Page";
  div_block1_signup.appendChild(div_block1_signup_h1);
  div_block1.appendChild(div_block1_signup);

  var div_block1_signup_input = document.createElement('div');
  div_block1_signup_input.className = 'signup-input';


  var div_block1_signup_input_i = document.createElement("i");
  div_block1_signup_input_i.className = "icon_style fa fa-user";
  div_block1_signup_input_i.setAttribute("aria-hidden", "true");
  div_block1_signup_input.appendChild(div_block1_signup_input_i);


  //User Name

  var div_block1_signup_input_username = document.createElement("input");
  div_block1_signup_input_username.className = 'fa input';
  div_block1_signup_input_username.setAttribute("type", "text");
  div_block1_signup_input_username.setAttribute("name", "user");
  div_block1_signup_input_username.setAttribute("placeholder",
    "Enter User Name");
  div_block1_signup_input.appendChild(div_block1_signup_input_username);


  //password
  var div_block1_signup_input_i2 = document.createElement("i");
  div_block1_signup_input_i2.className = "fa fa-unlock-alt";
  div_block1_signup_input_i2.setAttribute("aria-hidden", "true");
  div_block1_signup_input.appendChild(div_block1_signup_input_i2);

  var div_block1_signup_input_password = document.createElement("input");
  div_block1_signup_input_password.className = 'fa nameblock';
  div_block1_signup_input_password.setAttribute("type", "password");
  div_block1_signup_input_password.setAttribute("name", "pwd");
  div_block1_signup_input_password.setAttribute("placeholder", "Enter password");
  div_block1_signup_input.appendChild(div_block1_signup_input_password);



  //button


  var div_block1_signup_input_button = document.createElement("button");
  div_block1_signup_input_button.className = "signup-button";
  div_block1_signup_input_button.setAttribute("type", "submit");
  var div_block1_signup_input_button_h2 = document.createElement('h2');
  div_block1_signup_input_button_h2.innerHTML = 'Sign up now';
  div_block1_signup_input_button.appendChild(div_block1_signup_input_button_h2);
  div_block1_signup_input.appendChild(div_block1_signup_input_button);



  div_block1.appendChild(div_block1_signup_input);
  div_main.appendChild(div_block1);
  //Block1(signup) ends here


  //Block2(musicplayer)
  var div_block2_musicplayer = document.createElement('div');
  div_block2_musicplayer.className =
    "block2-musicplayer nopadding col-6 col-m-5";
  var div_musicplayer_text = document.createElement('div');
  div_musicplayer_text.className = "musicplayer-text";

  var ul_musicplayer_text_ul = document.createElement('ul');
  ul_musicplayer_text_ul.className = "musicplayer-style-for-list";

  var li_musicplayer_text_li = document.createElement('li');
  li_musicplayer_text_li.className = "musicplayer-font";


  var h2_musicplayer_text_h2 = document.createElement('h2');
  h2_musicplayer_text_h2.innerHTML = "Music Player";
  li_musicplayer_text_li.appendChild(h2_musicplayer_text_h2);

  var h3_musicplayer_text_h3 = document.createElement('h3');
  h3_musicplayer_text_h3.innerHTML = "Purple Haze";
  li_musicplayer_text_li.appendChild(h3_musicplayer_text_h3);


  ul_musicplayer_text_ul.appendChild(li_musicplayer_text_li);

  var li1_musicplayer_text_li1 = document.createElement('li');
  li1_musicplayer_text_li1.className = "musicplayer-font";


  var div_block2_musicplayer_icon_backward = document.createElement('div');
  div_block2_musicplayer_icon_backward.className = "fa fa-backward";
  div_block2_musicplayer_icon_backward.setAttribute("aria-hidden", "true");
  li1_musicplayer_text_li1.appendChild(div_block2_musicplayer_icon_backward);

  var div_block2_musicplayer_icon_pause = document.createElement('div');
  div_block2_musicplayer_icon_pause.className = "fa fa-pause";
  div_block2_musicplayer_icon_pause.setAttribute("aria-hidden", "true");
  li1_musicplayer_text_li1.appendChild(div_block2_musicplayer_icon_pause);

  var div_block2_musicplayer_icon_forward = document.createElement('div');
  div_block2_musicplayer_icon_forward.className = "fa fa-forward";
  div_block2_musicplayer_icon_forward.setAttribute("aria-hidden", "true");
  li1_musicplayer_text_li1.appendChild(div_block2_musicplayer_icon_forward);


  ul_musicplayer_text_ul.appendChild(li1_musicplayer_text_li1);
  div_musicplayer_text.appendChild(ul_musicplayer_text_ul);
  div_block2_musicplayer.appendChild(div_musicplayer_text);
  //Music player text ends here



  var div_musicplayer_sound_bar = document.createElement('div');
  div_musicplayer_sound_bar.className = "musicplayer-sound-bar";

  var div_musicplayer_wrapper = document.createElement('div');
  div_musicplayer_wrapper.className = "musicplayer-wrapper";



  var div_musicplayer_progress_bar = document.createElement('div');
  div_musicplayer_progress_bar.className = "musicplayer-progress-bar";

  var span_musicplayer_progress_bar_fill = document.createElement('span');
  span_musicplayer_progress_bar_fill.className =
    "musicplayer-progress-bar-fill";

  div_musicplayer_progress_bar.appendChild(span_musicplayer_progress_bar_fill);
  div_musicplayer_wrapper.appendChild(div_musicplayer_progress_bar);
  div_musicplayer_sound_bar.appendChild(div_musicplayer_wrapper);
  div_block2_musicplayer.appendChild(div_musicplayer_sound_bar);

  div_main.appendChild(div_block2_musicplayer);


  //block-3


  var div_block3 = document.createElement('div');
  div_block3.className = "block-3 col-4 col-m-6";

  var div_block3_settings = document.createElement('div');
  div_block3_settings.className = "settings";
  div_block3_settings_h3 = document.createElement('h3');
  div_block3_settings_h3.innerHTML = "Settings";
  div_block3_settings.appendChild(div_block3_settings_h3);


  var ul_settings_list_ul = document.createElement('ul');
  ul_settings_list_ul.className = "settings_list";

  //email address
  var li_settings_list_li = document.createElement('li');
  li_settings_list_li.className = "settings_head settings_sublists header-i";
  var input_settings_list_input = document.createElement('input');
  input_settings_list_input.className = "settings_options";
  input_settings_list_input.setAttribute("type", "text");
  input_settings_list_input.setAttribute("name", "email_address");
  input_settings_list_input.setAttribute("placeholder",
    "Add/Change email address");
  li_settings_list_li.appendChild(input_settings_list_input);
  ul_settings_list_ul.appendChild(li_settings_list_li);



  var li1_settings_list_li1 = document.createElement('li');
  li1_settings_list_li1.className = "settings_head settings_sublists";

  var p_settings_list_p = document.createElement('p');
  p_settings_list_p.className = "settings_options";
  p_settings_list_p.innerHTML = "Menu Sounds";



  var label_settings_list_label = document.createElement('label');
  label_settings_list_label.className = "switch";

  var label_settings_list_label_input = document.createElement('input');
  label_settings_list_label_input.setAttribute("type", "checkbox");
  label_settings_list_label_input.setAttribute("check", "checked");
  label_settings_list_label.appendChild(label_settings_list_label_input);

  var label_settings_list_label_input_span = document.createElement('span');
  label_settings_list_label_input_span.className = "slider round";
  label_settings_list_label.appendChild(label_settings_list_label_input_span);


  p_settings_list_p.appendChild(label_settings_list_label);
  li1_settings_list_li1.appendChild(p_settings_list_p);
  ul_settings_list_ul.appendChild(li1_settings_list_li1);



  var li1_settings_list_li1 = document.createElement('li');
  li1_settings_list_li1.className = "settings_head settings_sublists";

  var p_settings_list_p = document.createElement('p');
  p_settings_list_p.className = "settings_options";
  p_settings_list_p.innerHTML = "Restrictions";



  var label_settings_list_label = document.createElement('label');
  label_settings_list_label.className = "switch";

  var label_settings_list_label_input = document.createElement('input');
  label_settings_list_label_input.setAttribute("type", "checkbox");
  label_settings_list_label_input.setAttribute("check", "checked");
  label_settings_list_label.appendChild(label_settings_list_label_input);

  var label_settings_list_label_input_span = document.createElement('span');
  label_settings_list_label_input_span.className = "slider round";
  label_settings_list_label.appendChild(label_settings_list_label_input_span);


  p_settings_list_p.appendChild(label_settings_list_label);
  li1_settings_list_li1.appendChild(p_settings_list_p);
  ul_settings_list_ul.appendChild(li1_settings_list_li1);



  var li1_settings_list_li1 = document.createElement('li');
  li1_settings_list_li1.className = "settings_head settings_sublists";

  var p_settings_list_p = document.createElement('p');
  p_settings_list_p.className = "settings_options";
  p_settings_list_p.innerHTML = "FAQ";



  li1_settings_list_li1.appendChild(p_settings_list_p);
  ul_settings_list_ul.appendChild(li1_settings_list_li1);



  div_block3_settings.appendChild(ul_settings_list_ul);
  div_block3.appendChild(div_block3_settings);
  div_main.appendChild(div_block3);


  //Block 4(calender)

  var div_block4 = document.createElement('div');
  div_block4.className = 'block-4 col-5 col-m-5';

  var div_block4_calender = document.createElement('div');
  div_block4_calender.className = 'calender';



  var div_block4_calender_h2 = document.createElement('h2');
  div_block4_calender_h2.innerHTML = 'Calender';

  div_block4_calender.appendChild(div_block4_calender_h2);
  div_block4.appendChild(div_block4_calender);


  var div_block4_month = document.createElement('div');
  div_block4_month.className = 'month';


  var div_block4_month_ul = document.createElement('ul');

  var div_block4_month_ul_li = document.createElement('li');
  div_block4_month_ul_li.className = 'prev';
  div_block4_month_ul_li.innerHTML = '&#10094;';
  div_block4_month_ul.appendChild(div_block4_month_ul_li);

  var div_block4_month_ul_li = document.createElement('li');
  div_block4_month_ul_li.className = 'next';
  div_block4_month_ul_li.innerHTML = '&#10095;';
  div_block4_month_ul.appendChild(div_block4_month_ul_li);

  var div_block4_month_ul_li = document.createElement('li');
  div_block4_month_ul_li.innerHTML = 'October';
  div_block4_month_ul.appendChild(div_block4_month_ul_li);



  div_block4_month.appendChild(div_block4_month_ul);
  div_block4.appendChild(div_block4_month);



  var div_block4_weekdays = document.createElement('div');
  div_block4_weekdays.className = 'weekdays';

  var div_block4_weekdays_ul = document.createElement('ul');
  div_block4_weekdays_ul.className = 'weekdays';

  var div_block4_weekdays_ul_li = document.createElement('li');
  div_block4_weekdays_ul_li.innerHTML = 'Sun';
  div_block4_weekdays_ul.appendChild(div_block4_weekdays_ul_li);


  var div_block4_weekdays_ul_li = document.createElement('li');
  div_block4_weekdays_ul_li.innerHTML = 'Mon';
  div_block4_weekdays_ul.appendChild(div_block4_weekdays_ul_li);


  var div_block4_weekdays_ul_li = document.createElement('li');
  div_block4_weekdays_ul_li.innerHTML = 'Tue';
  div_block4_weekdays_ul.appendChild(div_block4_weekdays_ul_li);


  var div_block4_weekdays_ul_li = document.createElement('li');
  div_block4_weekdays_ul_li.innerHTML = 'Wed';
  div_block4_weekdays_ul.appendChild(div_block4_weekdays_ul_li);


  var div_block4_weekdays_ul_li = document.createElement('li');
  div_block4_weekdays_ul_li.innerHTML = 'Thu';
  div_block4_weekdays_ul.appendChild(div_block4_weekdays_ul_li);


  var div_block4_weekdays_ul_li = document.createElement('li');
  div_block4_weekdays_ul_li.innerHTML = 'Fri';
  div_block4_weekdays_ul.appendChild(div_block4_weekdays_ul_li);


  var div_block4_weekdays_ul_li = document.createElement('li');
  div_block4_weekdays_ul_li.innerHTML = 'Sat';
  div_block4_weekdays_ul.appendChild(div_block4_weekdays_ul_li);


  div_block4_weekdays.appendChild(div_block4_weekdays_ul);
  div_block4.appendChild(div_block4_weekdays);

  //Days in the calender

  var div_block4_days = document.createElement('div');
  div_block4_days.className = 'days';

  var div_block4_days_ul = document.createElement('ul');
  div_block4_days_ul.className = 'days';


  var div_block4_days_ul_li = document.createElement('li');
  var div_block4_days_ul_li_span = document.createElement('span');
  div_block4_days_ul_li_span.className = 'inactive';
  div_block4_days_ul_li_span.innerHTML = '26';
  div_block4_days_ul_li.appendChild(div_block4_days_ul_li_span);
  div_block4_days_ul.appendChild(div_block4_days_ul_li);


  var div_block4_days_ul_li = document.createElement('li');
  var div_block4_days_ul_li_span = document.createElement('span');
  div_block4_days_ul_li_span.className = 'inactive';
  div_block4_days_ul_li_span.innerHTML = '27';
  div_block4_days_ul_li.appendChild(div_block4_days_ul_li_span);
  div_block4_days_ul.appendChild(div_block4_days_ul_li);

  var div_block4_days_ul_li = document.createElement('li');
  var div_block4_days_ul_li_span = document.createElement('span');
  div_block4_days_ul_li_span.className = 'inactive';
  div_block4_days_ul_li_span.innerHTML = '28';
  div_block4_days_ul_li.appendChild(div_block4_days_ul_li_span);
  div_block4_days_ul.appendChild(div_block4_days_ul_li);

  var div_block4_days_ul_li = document.createElement('li');
  var div_block4_days_ul_li_span = document.createElement('span');
  div_block4_days_ul_li_span.className = 'inactive';
  div_block4_days_ul_li_span.innerHTML = '29';
  div_block4_days_ul_li.appendChild(div_block4_days_ul_li_span);
  div_block4_days_ul.appendChild(div_block4_days_ul_li);

  var div_block4_days_ul_li = document.createElement('li');
  var div_block4_days_ul_li_span = document.createElement('span');
  div_block4_days_ul_li_span.className = 'inactive';
  div_block4_days_ul_li_span.innerHTML = '30';
  div_block4_days_ul_li.appendChild(div_block4_days_ul_li_span);
  div_block4_days_ul.appendChild(div_block4_days_ul_li);

  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '1';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);

  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '2';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);

  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '3';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);

  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '4';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);

  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '5';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);

  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '6';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);

  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '7';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);

  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '8';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);

  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '9';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);

  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '10';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);

  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '11';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);


  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '12';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);


  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '13';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);


  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '14';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);


  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '15';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);


  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '16';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);


  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '17';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);


  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '18';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);


  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '19';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);


  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '20';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);


  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '21';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);


  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '22';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);


  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '23';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);
  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '24';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);
  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '25';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);
  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '26';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);
  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '27';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);
  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '28';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);
  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '29';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);
  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '30';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);
  var div_block4_days_ul_li = document.createElement('li');
  div_block4_days_ul_li.innerHTML = '31';
  div_block4_days_ul.appendChild(div_block4_days_ul_li);
  var div_block4_days_ul_li = document.createElement('li');

  div_block4_days.appendChild(div_block4_days_ul);
  div_block4.appendChild(div_block4_days);
  div_main.appendChild(div_block4);


  //Block 5(User profile)

  var div_block5 = document.createElement('div');
  div_block5.className = 'userprofile col-5 col-m-5';


  var div_block5_userprofile1 = document.createElement('div');
  div_block5_userprofile1.className = 'userprofile1';

  var div_block5_userprofile1_h2 = document.createElement('h2');
  div_block5_userprofile1_h2.innerHTML = 'User Profile';
  div_block5_userprofile1.appendChild(div_block5_userprofile1_h2);
  div_block5.appendChild(div_block5_userprofile1);

  var div_block5_userprofile2 = document.createElement('div');
  div_block5_userprofile2.className = 'userprofile2';


  var div_block5_userprofile2_image = document.createElement('img');
  div_block5_userprofile2_image.className = 'w3-circle';
  div_block5_userprofile2_image.setAttribute("src", "images/image.jpeg");
  div_block5_userprofile2_image.setAttribute("alt", "image not found");
  div_block5_userprofile2_image.setAttribute("style", "width:50%");
  div_block5_userprofile2.appendChild(div_block5_userprofile2_image);


  var div_block5_userprofile2_h3 = document.createElement('h3');
  div_block5_userprofile2_h3.innerHTML = "Bob Parker";
  div_block5_userprofile2.appendChild(div_block5_userprofile2_h3);

  var div_block5_userprofile2_h5 = document.createElement('h5');
  div_block5_userprofile2_h5.innerHTML = "Hey you play more games";
  div_block5_userprofile2.appendChild(div_block5_userprofile2_h5);
  div_block5.appendChild(div_block5_userprofile2);

  var div_block5_userprofile3 = document.createElement('div');
  div_block5_userprofile3.className = 'userprofile3';

  var div_block5_userprofile3_proficons = document.createElement('div');
  div_block5_userprofile3_proficons.className = 'prof-icons';

  var div_block5_userprofile3_proficons_1 = document.createElement('div');
  div_block5_userprofile3_proficons_1.className = 'prof-icon-1';

  var div_block5_userprofile3_proficons_1_i = document.createElement('i');
  div_block5_userprofile3_proficons_1_i.className = 'fa fa-heart ic1';
  div_block5_userprofile3_proficons_1_i.setAttribute("aria-hidden", "true");
  div_block5_userprofile3_proficons_1.appendChild(
    div_block5_userprofile3_proficons_1_i);

  var div_block5_userprofile3_proficons_1_br = document.createElement('br');
  div_block5_userprofile3_proficons_1.appendChild(
    div_block5_userprofile3_proficons_1_br);

  var div_block5_userprofile3_proficons_1_span = document.createElement('span');
  div_block5_userprofile3_proficons_1_span.setAttribute("style", "color:black");
  div_block5_userprofile3_proficons_1_span.innerHTML = "140";
  div_block5_userprofile3_proficons_1.appendChild(
    div_block5_userprofile3_proficons_1_span);
  div_block5_userprofile3_proficons.appendChild(
    div_block5_userprofile3_proficons_1);



  var div_block5_userprofile3_proficons_2 = document.createElement('label');
  div_block5_userprofile3_proficons_2.className = 'prof-icon-2';

  var div_block5_userprofile3_proficons_2_i = document.createElement('i');
  div_block5_userprofile3_proficons_2_i.className = 'fa fa-users ic1';
  div_block5_userprofile3_proficons_2_i.setAttribute("aria-hidden", "true");
  div_block5_userprofile3_proficons_2.appendChild(
    div_block5_userprofile3_proficons_2_i);

  var div_block5_userprofile3_proficons_2_br = document.createElement('br');
  div_block5_userprofile3_proficons_2.appendChild(
    div_block5_userprofile3_proficons_2_br);

  var div_block5_userprofile3_proficons_2_span = document.createElement('span');
  div_block5_userprofile3_proficons_2_span.innerHTML = "156";
  div_block5_userprofile3_proficons_2.appendChild(
    div_block5_userprofile3_proficons_2_span);
  div_block5_userprofile3_proficons.appendChild(
    div_block5_userprofile3_proficons_2);



  var div_block5_userprofile3_proficons_3 = document.createElement('label');
  div_block5_userprofile3_proficons_3.className = 'prof-icon-2';

  var div_block5_userprofile3_proficons_3_i = document.createElement('i');
  div_block5_userprofile3_proficons_3_i.className = 'fa fa-eye ic1';
  div_block5_userprofile3_proficons_3_i.setAttribute("aria-hidden", "true");
  div_block5_userprofile3_proficons_3.appendChild(
    div_block5_userprofile3_proficons_3_i);

  var div_block5_userprofile3_proficons_3_br = document.createElement('br');
  div_block5_userprofile3_proficons_3.appendChild(
    div_block5_userprofile3_proficons_3_br);

  var div_block5_userprofile3_proficons_3_span = document.createElement('span');
  div_block5_userprofile3_proficons_3_span.innerHTML = "11,990";
  div_block5_userprofile3_proficons_3.appendChild(
    div_block5_userprofile3_proficons_3_span);
  div_block5_userprofile3_proficons.appendChild(
    div_block5_userprofile3_proficons_3);


  div_block5_userprofile3.appendChild(div_block5_userprofile3_proficons);
  div_block5.appendChild(div_block5_userprofile3);
  div_main.appendChild(div_block5);

  //Block 6

  var div_block6_socialmedia = document.createElement('div');
  div_block6_socialmedia.className = 'socialmedia col-5 col-m-2';

  var div_block6_socialmedia_social = document.createElement('div');
  div_block6_socialmedia_social.className = 'social';
  var div_block6_socialmedia_social_h2 = document.createElement('h2');
  div_block6_socialmedia_social_h2.innerHTML = 'Social';
  div_block6_socialmedia_social.appendChild(div_block6_socialmedia_social_h2);
  div_block6_socialmedia.appendChild(div_block6_socialmedia_social);

  //images
  var div_block6_socialmedia_imagesocial = document.createElement('div');
  div_block6_socialmedia_imagesocial.className = 'imagesocial';

  var div_block6_socialmedia_imagesocial_imageblocks = document.createElement(
    'div');
  div_block6_socialmedia_imagesocial_imageblocks.className = 'imageblocks';

  var div_block6_socialmedia_imagesocial_imageblocks_image = document.createElement(
    'img');
  div_block6_socialmedia_imagesocial_imageblocks_image.setAttribute("src",
    "images/facebook2.png");
  div_block6_socialmedia_imagesocial_imageblocks_image.setAttribute("alt",
    "Facebook Icon");
  div_block6_socialmedia_imagesocial_imageblocks_image.setAttribute("height",
    "50");
  div_block6_socialmedia_imagesocial_imageblocks_image.setAttribute("width",
    "70");

  div_block6_socialmedia_imagesocial_imageblocks.appendChild(
    div_block6_socialmedia_imagesocial_imageblocks_image);
  div_block6_socialmedia_imagesocial.appendChild(
    div_block6_socialmedia_imagesocial_imageblocks);



  var div_block6_socialmedia_imagesocial_imageblocks = document.createElement(
    'div');
  div_block6_socialmedia_imagesocial_imageblocks.className = 'imageblocks';
  var div_block6_socialmedia_imagesocial_imageblocks_image = document.createElement(
    'img');
  div_block6_socialmedia_imagesocial_imageblocks_image.setAttribute("src",
    "images/twitter.png");
  div_block6_socialmedia_imagesocial_imageblocks_image.setAttribute("alt",
    "Twitter Icon");
  div_block6_socialmedia_imagesocial_imageblocks_image.setAttribute("height",
    "50");
  div_block6_socialmedia_imagesocial_imageblocks_image.setAttribute("width",
    "70");

  div_block6_socialmedia_imagesocial_imageblocks.appendChild(
    div_block6_socialmedia_imagesocial_imageblocks_image);
  div_block6_socialmedia_imagesocial.appendChild(
    div_block6_socialmedia_imagesocial_imageblocks);



  var div_block6_socialmedia_imagesocial_imageblocks = document.createElement(
    'div');
  div_block6_socialmedia_imagesocial_imageblocks.className = 'imageblocks';
  var div_block6_socialmedia_imagesocial_imageblocks_image = document.createElement(
    'img');
  div_block6_socialmedia_imagesocial_imageblocks_image.setAttribute("src",
    "images/stumble.png");
  div_block6_socialmedia_imagesocial_imageblocks_image.setAttribute("alt",
    "Stumble Icon");
  div_block6_socialmedia_imagesocial_imageblocks_image.setAttribute("height",
    "50");
  div_block6_socialmedia_imagesocial_imageblocks_image.setAttribute("width",
    "70");

  div_block6_socialmedia_imagesocial_imageblocks.appendChild(
    div_block6_socialmedia_imagesocial_imageblocks_image);


  div_block6_socialmedia_imagesocial.appendChild(
    div_block6_socialmedia_imagesocial_imageblocks);

  var div_block6_socialmedia_imagesocial_imageblocks = document.createElement(
    'div');
  div_block6_socialmedia_imagesocial_imageblocks.className = 'imageblocks';
  var div_block6_socialmedia_imagesocial_imageblocks_image = document.createElement(
    'img');
  div_block6_socialmedia_imagesocial_imageblocks_image.setAttribute("src",
    "images/dribble.png");
  div_block6_socialmedia_imagesocial_imageblocks_image.setAttribute("alt",
    "Dribble Icon");
  div_block6_socialmedia_imagesocial_imageblocks_image.setAttribute("height",
    "50");
  div_block6_socialmedia_imagesocial_imageblocks_image.setAttribute("width",
    "70");

  div_block6_socialmedia_imagesocial_imageblocks.appendChild(
    div_block6_socialmedia_imagesocial_imageblocks_image);



  div_block6_socialmedia_imagesocial.appendChild(
    div_block6_socialmedia_imagesocial_imageblocks);



  div_block6_socialmedia.appendChild(div_block6_socialmedia_imagesocial);
  div_main.appendChild(div_block6_socialmedia);


  //Block 7(Weather)

  var div_block7_weather = document.createElement('div');
  div_block7_weather.className = "block7-weather col-4 col-m-4";

  var div_block7_weather_head = document.createElement('div');
  div_block7_weather_head.className = "weather-head";

  var div_block7_weather_head_h2 = document.createElement('h2');
  div_block7_weather_head_h2.innerHTML = "21<sup>o</sup>";
  div_block7_weather_head.appendChild(div_block7_weather_head_h2);
  div_block7_weather.appendChild(div_block7_weather_head);

  var div_block7_weather_place = document.createElement('div');
  div_block7_weather_place.className = "weather-head-place";

  var div_block7_weather_place_img = document.createElement('img');
  div_block7_weather_place_img.setAttribute("src", "images/cloud.png");
  div_block7_weather_place_img.setAttribute("class", "align-right");
  div_block7_weather_place_img.setAttribute("alt", "Cloud Icon");
  div_block7_weather_place_img.setAttribute("height", "50");
  div_block7_weather_place_img.setAttribute("width", "50");
  div_block7_weather_place.appendChild(div_block7_weather_place_img);

  var div_block7_weather_place_text = document.createElement('label');
  div_block7_weather_place_text.className = "weather-head-text";
  div_block7_weather_place_text.innerHTML = "Liverpool,UK";
  div_block7_weather_place.appendChild(div_block7_weather_place_text);

  div_block7_weather.appendChild(div_block7_weather_place);


  var div_block7_weather_tommorow = document.createElement('div');
  div_block7_weather_tommorow.className = "weather-tommorow";
  div_block7_weather_tommorow.innerHTML = "Tommorow";

  var div_block7_weather_tommorow_img = document.createElement('img');
  div_block7_weather_tommorow_img.setAttribute("src", "images/cloud.png");
  div_block7_weather_tommorow_img.setAttribute("class", "align-right");
  div_block7_weather_tommorow_img.setAttribute("alt", "Cloud Icon");
  div_block7_weather_tommorow_img.setAttribute("height", "50");
  div_block7_weather_tommorow_img.setAttribute("width", "50");
  div_block7_weather_tommorow.appendChild(div_block7_weather_tommorow_img);

  div_block7_weather_tommorow_text = document.createElement('div');
  div_block7_weather_tommorow_text.className = "align-right";
  div_block7_weather_tommorow_text.innerHTML = "23 <sup>o</sup>";
  div_block7_weather_tommorow.appendChild(div_block7_weather_tommorow_text);

  div_block7_weather.appendChild(div_block7_weather_tommorow);



  var div_block7_weather_friday = document.createElement('div');
  div_block7_weather_friday.className = "weather-friday";
  div_block7_weather_friday.innerHTML = "Friday";

  var div_block7_weather_friday_img = document.createElement('img');
  div_block7_weather_friday_img.setAttribute("src", "images/cloud.png");
  div_block7_weather_friday_img.setAttribute("class", "align-right");
  div_block7_weather_friday_img.setAttribute("alt", "Cloud Icon");
  div_block7_weather_friday_img.setAttribute("height", "50");
  div_block7_weather_friday_img.setAttribute("width", "50");
  div_block7_weather_friday.appendChild(div_block7_weather_friday_img);

  div_block7_weather_friday_text = document.createElement('div');
  div_block7_weather_friday_text.className = "align-right";
  div_block7_weather_friday_text.innerHTML = "23 <sup>o</sup>";
  div_block7_weather_friday.appendChild(div_block7_weather_friday_text);

  div_block7_weather.appendChild(div_block7_weather_friday);



  var div_block7_weather_saturday = document.createElement('div');
  div_block7_weather_saturday.className = "weather-saturday";
  div_block7_weather_saturday.innerHTML = "Saturday";

  var div_block7_weather_saturday_img = document.createElement('img');
  div_block7_weather_saturday_img.setAttribute("src", "images/rainycloud.png");
  div_block7_weather_saturday_img.setAttribute("class", "align-right");
  div_block7_weather_saturday_img.setAttribute("alt", "Cloud Icon");
  div_block7_weather_saturday_img.setAttribute("height", "50");
  div_block7_weather_saturday_img.setAttribute("width", "50");
  div_block7_weather_saturday.appendChild(div_block7_weather_saturday_img);

  div_block7_weather_saturday_text = document.createElement('div');
  div_block7_weather_saturday_text.className = "align-right";
  div_block7_weather_saturday_text.innerHTML = "19 <sup>o</sup>";
  div_block7_weather_saturday.appendChild(div_block7_weather_saturday_text);

  div_block7_weather.appendChild(div_block7_weather_saturday);



  div_main.appendChild(div_block7_weather);



  body.appendChild(div_main);
}
